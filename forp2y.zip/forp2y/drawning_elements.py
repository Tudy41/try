import global_variables
import pygame
pygame.init()
def draw_background_lines():
    x_hor=0
    x_ver=0
    y_hor=0
    y_ver=0
    for it in range(1,15):
        x_ver=it*global_variables.window_length//9
        y_ver=0
        pygame.draw.line(global_variables.window,(255,255,255),(x_ver,y_ver),(x_ver,global_variables.window_height))
        x_hor=0
        y_hor=it*global_variables.window_height//9
        pygame.draw.line(global_variables.window,(255,255,255),(x_hor,y_hor),(global_variables.window_length,y_hor))


def draw_axis_for_x_y():

    pygame.draw.line(global_variables.window,(255,255,255),(0,global_variables.window_height//2),(global_variables.window_length,global_variables.window_height//2))
    pygame.draw.line(global_variables.window,(255,255,255),(global_variables.window_length//2,0),(global_variables.window_length//2,global_variables.window_height))

    x_sign=global_variables.font.render('X',True,(255,255,255))
    y_sign=global_variables.font.render('Y', True, (255, 255, 255))
    global_variables.window.blit(x_sign,(global_variables.window_length-23,global_variables.window_height//2-32))
    global_variables.window.blit(y_sign,(global_variables.window_length//2+10,10))

    step_x=global_variables.window_length//10
    step_y=global_variables.window_height//10

    for i in range(1,15):

        value_x=int((i*step_x-global_variables.window_length//2)/global_variables.zoom)
        value_y=int((global_variables.window_height//2-i*step_y)/global_variables.zoom)

        value_sign=global_variables.font.render(repr(value_x),True,(255,255,255))
        global_variables.window.blit(value_sign,(i*step_x+5,global_variables.window_height//2+5))

        value_sign=global_variables.font.render(repr(value_y),True,(255,255,255))
        global_variables.window.blit(value_sign,(global_variables.window_length//2+5,i*step_y+5))
def draw_text_box_input():
    pygame.draw.rect(global_variables.window, global_variables.color_text, global_variables.text_box_window, 2)
    global_variables.text_box_txt_inserted_zone = global_variables.font.render(f'{global_variables.text_inserted}',
                                                                               True, (255, 255, 255))
    global_variables.text_place = global_variables.text_box_txt_inserted_zone.get_rect(
        midbottom=(global_variables.text_box_window.centerx, global_variables.text_box_window.centery + 15))
    global_variables.window.blit(global_variables.text_box_txt_inserted_zone, global_variables.text_place)

def draw_current_points():
    for p in global_variables.list_points:
        px, py = p
        window_x = int(px *global_variables. zoom +global_variables. window_length // 2)
        window_y = int(global_variables.window_height // 2 - py * global_variables.zoom)
        pygame.draw.circle(global_variables.window, (0, 0, 255), (window_x, window_y), 6)


