import sys,pygame
import tkinter
import drawning_elements
import global_variables
pygame.init()

pygame.display.set_caption('Least squares method')


def app_runner():

    while global_variables.running:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:

                pygame.quit()
                exit(0)
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_RETURN:
                    coords=global_variables.text_inserted.strip('()').split(',',maxsplit=1)
                    float_coords=(float(coords[0]),float(coords[1]))
                    global_variables.list_points.append(float_coords)
                    global_variables.text_inserted=''
                elif event.key==pygame.K_BACKSPACE:
                    global_variables.text_inserted=''
                    for it in range(0,len(global_variables.text_inserted)-1):
                        global_variables.text_inserted=global_variables.text_inserted+it


                else:
                    actual_width=global_variables.font.size(global_variables.text_inserted+event.unicode)[0]
                    if actual_width<global_variables.text_box_width-10:
                        global_variables.text_inserted=global_variables.text_inserted+event.unicode

            elif event.type==pygame.MOUSEBUTTONDOWN:
                if event.button==1:
                    x=event.pos[0]
                    y=event.pos[1]

                    if global_variables.save_btn.collidepoint(x,y):
                        save()
                    elif global_variables.reset_btn.collidepoint(x,y):
                        reset()
                    elif not global_variables.text_box_window.collidepoint(event.pos):

                        for p in global_variables.list_points:
                            px,py=p
                            screen_x=int(px*global_variables.zoom+global_variables.window_length//2)
                            screen_y=int(global_variables.window_height//2-py*global_variables.zoom)
                            selected_point=None
                            if pygame.Rect(screen_x-10,screen_y-10,20,20).collidepoint(x,y):
                                selected_point=p
                                is_dragging=True
                                break

                            else:
                                x_csystem=(x-global_variables.window_length//2)/global_variables.zoom
                                y_csystem=(global_variables.window_height//2-y)/global_variables.zoom
                                global_variables.list_points.append((x_csystem,y_csystem))
                                global_variables.text_inserted=""
                    elif event.button==3:
                        x=event.pos[0]
                        y=event.pos[1]
                        for p in global_variables.list_points:
                            x_p,y_p=p
                            window_x=int(x_p*global_variables.zoom+global_variables.window_length//2)
                            window_y=int(global_variables.window_height//2-y_p*global_variables.zoom)
                            if pygame.Rect(window_x-10,window_y-10,20,20).collidepoint(x,y):
                                global_variables.list_points.remove(p)
                    elif event.button==4:
                        global_variables.zoom=global_variables.zoom*1.2
                    elif event.button==5:
                        global_variables.zoom=global_variables.zoom/1.2

                elif event.type==pygame.MOUSEMOTION:
                  pass


        global_variables.window.fill(global_variables.color_for_background_rgb)

        drawning_elements.draw_background_lines()
        drawning_elements.draw_axis_for_x_y()

        drawning_elements.draw_current_points()

        global_variables.window.blit(global_variables.add_point_text_surface,global_variables.add_point_text_rect.topleft)

        drawning_elements.draw_text_box_input()







        pygame.display.flip()
        global_variables.clock.tick(60)

app_runner()


