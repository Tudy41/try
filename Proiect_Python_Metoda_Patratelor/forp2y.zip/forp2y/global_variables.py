import pygame
pygame.init()
window_length=880
window_height=650

color_for_background_rgb=tuple((0,0,0))
running=True
clock=pygame.time.Clock()


add_point_text='ADD POINT:'
font=pygame.font.Font(None,43)
zoom=1.0
window=pygame.display.set_mode((window_length,window_height))

text_box_width=216
text_box_window=pygame.Rect(20,562,206,40)
text_box_txt_inserted_zone=font.render('ADD POINT:',True,(255,255,255))
text_place=text_box_txt_inserted_zone.get_rect(midbottom=(text_box_window.centerx,text_box_window.top-5))
text_inserted=""
list_points=list()


add_point_text = "ADD POINT:"
add_point_text_surface = font.render(add_point_text, True, (255, 255, 255))
add_point_text_rect = add_point_text_surface.get_rect(midleft=(20, 624))


color_text=pygame.Color('aqua')

save_btn=pygame.Rect(20,607,94,34)
reset_btn=pygame.Rect(131,607,94,34)
save_color=pygame.Color('dodgerblue2')
reset_color=pygame.Color('darkorange')