#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "Shlwapi.lib")

#include <cstdlib>

#include <ShlObj.h>
#include <strsafe.h>

#include <tchar.h>
#include <Windows.h>
#include <Shlwapi.h>
#include <wininet.h>

#include "worker_env.h"

constexpr auto window_padding = 15;
constexpr auto button_height = 40;
constexpr auto empty_link_err_message = _T("[Warning] Input is empty!\n");
constexpr auto invalid_url_err_message = _T("[Warning] Input does not respect an URL format!\n");

DWORD worker_thread_id;
HANDLE worker_thread_handle;

// graphics related variables
namespace {
	constexpr TCHAR main_window_class[] = _T("DesktopApp");

	constexpr TCHAR main_window_title[] = _T("Http WinAPI");

	HINSTANCE hInst;

	HWND input_text, logs_box, start_btn;

	enum actions {
		input_text_handling = 1,
		program_log,
		click_start
	};
}

// Forward declarations of functions included in this code module:
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

void append_text_to(HWND edit_handle, const TCHAR* text) {
	const auto size = GetWindowTextLength(edit_handle);

	SendMessage(edit_handle, EM_SETSEL, size, size);

	SendMessage(edit_handle, EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(text));
}

// Worker Functions
void init();
DWORD worker(LPVOID parameters);
void execute_config_instructions();
void post_stats(const size_t file_sizes, const LPCTSTR url);
void get_contents_from(const LPCTSTR url);
size_t size_of_folder(const LPCTSTR folder_path);
void post_data_to(const LPCTSTR url, const LPCTSTR data);
TCHAR* get_and_place(const LPCTSTR url, const LPCTSTR file_path);

int WINAPI WinMain(
	_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPSTR     lpCmdLine,
	_In_ int       nCmdShow
) {
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(wcex.hInstance, IDI_APPLICATION);
	wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
	wcex.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
	wcex.lpszMenuName = nullptr;
	wcex.lpszClassName = main_window_class;
	wcex.hIconSm = LoadIcon(wcex.hInstance, IDI_APPLICATION);

	if (!RegisterClassEx(&wcex)) {
		MessageBox(nullptr,
			_T("Call to RegisterClassEx failed!"),
			_T("Windows Desktop Guided Tour"),
			NULL);

		return 1;
	}

	hInst = hInstance;

	const HWND hWnd = CreateWindowEx(
		WS_EX_OVERLAPPEDWINDOW,
		main_window_class,
		main_window_title,
		WS_OVERLAPPEDWINDOW & ~WS_THICKFRAME,
		CW_USEDEFAULT, CW_USEDEFAULT,
		960, 600,
		nullptr,
		nullptr,
		hInstance,
		nullptr
	);

	if (!hWnd) {
		MessageBox(nullptr,
			_T("Call to CreateWindow failed!"),
			_T("Windows Desktop Guided Tour"),
			NULL);

		return 1;
	}

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	MSG msg;
	while (GetMessage(&msg, nullptr, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return static_cast<int>(msg.wParam);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	PAINTSTRUCT ps;

	RECT main_window;

	GetClientRect(hWnd, &main_window);

	switch (message) {
		case WM_CREATE:{
			// get text height
			const HDC handle_device = GetDC(hWnd);

			TEXTMETRIC text_metric;
			GetTextMetrics(handle_device, &text_metric);

			ReleaseDC(hWnd, handle_device);

			input_text = CreateWindow(
				_T("EDIT"),
				_T("https://cssohw.herokuapp.com/assignhomework/310910401RSL211262"),
				WS_CHILD | WS_VISIBLE | ES_CENTER,
				2 * window_padding,
				window_padding,
				main_window.right - 4 * window_padding,
				text_metric.tmHeight,
				hWnd,
				reinterpret_cast<HMENU>(input_text_handling),
				reinterpret_cast<HINSTANCE>(GetWindowLongPtr(hWnd, GWLP_HINSTANCE)),
				nullptr
			);

			start_btn = CreateWindow(
				_T("BUTTON"),
				_T("Start"),
				WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
				window_padding,
				2 * window_padding + button_height,
				main_window.right - 2 * window_padding,
				button_height,
				hWnd,
				reinterpret_cast<HMENU>(click_start),
				reinterpret_cast<HINSTANCE>(GetWindowLongPtr(hWnd, GWLP_HINSTANCE)),
				NULL
			);

			logs_box = CreateWindow(
				_T("EDIT"),
				nullptr,
				WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY,
				window_padding,
				3 * window_padding + 2 * button_height,
				main_window.right - 2 * window_padding,
				main_window.bottom - 4 * window_padding - 2 * button_height,
				hWnd,
				reinterpret_cast<HMENU>(program_log),
				NULL,
				NULL
			);

			break;
		}
		case WM_COMMAND: {
			switch (LOWORD(wParam)) {
				case click_start:{
						if(GetWindowTextLength(input_text) == 0){
							append_text_to(logs_box, empty_link_err_message);
							break;
						}
						if(worker_thread_id){
							append_text_to(logs_box, _T("[Warning] Worker is running!\n"));
							break;
						}
						if (worker_thread_handle)
							CloseHandle(worker_thread_handle);
						TCHAR url[INTERNET_MAX_URL_LENGTH] = {};
						GetWindowText(input_text, url, INTERNET_MAX_URL_LENGTH);
						if(!PathIsURL(url))
						{
							append_text_to(logs_box, invalid_url_err_message);
							break;
						}

						worker_thread_handle = CreateThread(
							nullptr,
							0,
							worker,
							_tcsdup(url),
							0,
							& worker_thread_id
						);

						if(!worker_thread_handle){
							append_text_to(logs_box, _T("Failed to start worker!\n"));
							break;
						}

					break;
				}
				default:
					break;
			}
			break;
		}
		case WM_PAINT: {

			HDC hdc = BeginPaint(hWnd, &ps);

			const RECT rect_sizes = { window_padding, window_padding, main_window.right - window_padding, window_padding + button_height };

			FrameRect(hdc, &rect_sizes, static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));

			EndPaint(hWnd, &ps);
			break;
		}
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}


// Worker Functions definitions
void init() {
	TCHAR message[max_message] = {};
	for (auto& current_path : directories) {
		if (!CreateDirectory(current_path, nullptr)) {

			if (GetLastError() == ERROR_ALREADY_EXISTS) {
				_sntprintf_s(
					message,
					sizeof(message) >> (sizeof(TCHAR) - 1),
					_T("[Warning] The directory \'%s\' already exists!\n"),
					current_path
				);

				append_text_to(logs_box, message);

				continue;
			}

			_sntprintf_s(
				message,
				sizeof(message) >> (sizeof(TCHAR) - 1),
				_T("[Error C%hu] Failed to create the directory : % s\n"),
				GetLastError(),
				current_path
			);

			append_text_to(logs_box, message);

			std::_Exit(EXIT_FAILURE);
		}
	}
}

void get_contents_from(const LPCTSTR url) {
	const HANDLE config_file_handle = CreateFile(
		config_file_path,
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ,
		nullptr,
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		nullptr
	);

	if (config_file_handle == INVALID_HANDLE_VALUE) {

		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] Failed to create file \'%s\'!\n"),
			GetLastError(),
			config_file_path
		);

		append_text_to(logs_box, message_log);
		std::_Exit(EXIT_FAILURE);
	}

	const HANDLE internet_handle = InternetOpen(
		student_identifier,
		INTERNET_OPEN_TYPE_DIRECT,
		nullptr,
		nullptr,
		0
	);

	if (!internet_handle) {
		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] InternetOpen() failed!\n"),
			GetLastError()
		);

		append_text_to(logs_box, message_log);

		CloseHandle(config_file_handle);

		std::_Exit(EXIT_FAILURE);
	}

	const HANDLE connection_handle = InternetOpenUrl(
		internet_handle,
		url,
		agent_header,
		static_cast<DWORD>(_tcslen(agent_header)),
		INTERNET_FLAG_RELOAD,
		0
	);

	if (!connection_handle) {

		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] InternetOpenUrl() failed!\n"),
			GetLastError()
		);

		append_text_to(logs_box, message_log);

		InternetCloseHandle(internet_handle);
		CloseHandle(config_file_handle);
		std::_Exit(EXIT_FAILURE);
	}

	DWORD bytes_read;
	CHAR buffer[page_size] = {};
	TCHAR generic_buffer[page_size] = {};

	_sntprintf_s(
		message_log,
		message_log_size,
		_T("%s GET %s\n"),
		url,
		agent_header
	);

	append_text_to(logs_box, message_log);

	while (InternetReadFile(
		connection_handle,
		buffer,
		sizeof(buffer),
		&bytes_read
	) && bytes_read > 0) {
#ifdef UNICODE
		MultiByteToWideChar(CP_UTF8, 0, buffer, -1, generic_buffer, sizeof(generic_buffer) >> 1);
#else
		generic_buffer = buffer;
#endif
		append_text_to(logs_box, generic_buffer);

		if (!WriteFile(
			config_file_handle,
			buffer,
			bytes_read,
			nullptr,
			nullptr
		)) {

			_sntprintf_s(
				message_log,
				message_log_size,
				_T("[Error C%hu] Failed to write in \'%s\'\n"),
				GetLastError(),
				config_file_path
			);

			append_text_to(logs_box, generic_buffer);

			CloseHandle(config_file_handle);
			InternetCloseHandle(connection_handle);
			InternetCloseHandle(internet_handle);

			std::_Exit(EXIT_FAILURE);
		}
	}

	InternetCloseHandle(connection_handle);
	InternetCloseHandle(internet_handle);
	CloseHandle(config_file_handle);
}

void post_stats(const size_t file_sizes, const LPCTSTR url) {

	TCHAR finish_endpoint[INTERNET_MAX_URL_LENGTH] = {}, data[MAX_PATH] = {};

	_sntprintf_s(
		finish_endpoint,
		sizeof(finish_endpoint) >> (sizeof(TCHAR) - 1),
		_T("%s%s"),
		url,
		_T("endhomework")
	);

	_sntprintf_s(
		data,
		sizeof(data) >> (sizeof(TCHAR) - 1),
		_T("id=%s&total=%lu&get=%lu&post=%lu&size=%llu"),
		student_identifier,
		get_requests_number + post_requests_number,
		get_requests_number,
		post_requests_number,
		file_sizes
	);

	post_data_to(finish_endpoint, data);
}

void execute_config_instructions() {
	const HANDLE config_file_handle = CreateFile(
		config_file_path,
		GENERIC_READ,
		FILE_SHARE_READ,
		nullptr,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		nullptr
	);

	TCHAR generic_buffer[page_size] = {};

	if (config_file_handle == INVALID_HANDLE_VALUE) {

		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] Failed to open file \'%s\'!\n"),
			GetLastError(),
			config_file_path
		);

		append_text_to(logs_box, message_log);

		std::_Exit(EXIT_FAILURE);
	}

	CHAR buffer[page_size] = {};

	DWORD bytes_read = sizeof(buffer) - 1;

	while (bytes_read == sizeof(buffer) - 1 && ReadFile(
		config_file_handle,
		buffer,
		sizeof(buffer),
		&bytes_read,
		nullptr
	)) {
		TCHAR* line_context = nullptr;
#ifdef UNICODE
		MultiByteToWideChar(CP_UTF8, 0, buffer, -1, generic_buffer, sizeof(generic_buffer) >> 1);
#else
		t_buffer = buffer;
#endif

		const auto pointer_to_last_newline = _tcsrchr(generic_buffer, _T('\n'));

		const auto last_newline_pos = _tcslen(pointer_to_last_newline);

		*pointer_to_last_newline = _T('\0');

		auto line = _tcstok_s(generic_buffer, _T("\r\n"), &line_context);

		TCHAR* last_get_value = nullptr;

		while (line) {
			const auto separator = _tcschr(line, _T(':'));
			*separator = _T('\0');


			const auto link = separator + 1, method = line;

			const auto value = _tcsrchr(link, _T('/')) + 1;

			TCHAR path_builder[MAX_PATH] = {};

			if (!_tcsstr(link, _T("dohomework_additional"))) {
				if (!_tcscmp(method, _T("GET"))) {

					_sntprintf_s(
						path_builder,
						sizeof(path_builder) << (sizeof(TCHAR) - 1),
						_T("%s\\%s"),
						directories[download_folder_index],
						value
					);

					// get_and_place returns a heap allocated memory
					// if last_get_value is already assigned, it must free
					// previous get_and_place value, in order to avoid memory leaks
					if (last_get_value)
						free(last_get_value);

					last_get_value = get_and_place(link, path_builder);

					get_requests_number++;
				}else if (!_tcscmp(method, _T("POST"))) {
					TCHAR formatted_data[MAX_PATH] = {};

					_sntprintf_s(
						formatted_data,
						sizeof(formatted_data) >> (sizeof(TCHAR) - 1),
						_T("id=%s&value=%s"),
						student_identifier,
						last_get_value
					);

					post_data_to(link, formatted_data);

					post_requests_number++;
				}
			}
			else {

				_sntprintf_s(
					path_builder,
					sizeof(path_builder) << (sizeof(TCHAR) - 1),
					_T("%s/%s_additional.txt"),
					directories[download_folder_index],
					value
				);

				if (last_get_value)
					free(last_get_value);

				last_get_value = get_and_place(link, path_builder);

				get_requests_number++;

				*_tcsrchr(link, _T('/')) = _T('\0');

				TCHAR param_endpoint[INTERNET_MAX_URL_LENGTH] = {};

				while (_tstoi(last_get_value)) {
					// get_and_place returns a heap allocated memory
					// if last_get_value is already assigned, it must free
					// previous get_and_place value, in order to avoid memory leaks

					_sntprintf_s(
						param_endpoint,
						sizeof(param_endpoint) >> (sizeof(TCHAR) - 1),
						_T("%s/%s"),
						link,
						last_get_value
					);

					if (last_get_value)
						free(last_get_value);

					last_get_value = get_and_place(param_endpoint, path_builder);
					get_requests_number++;

					memset(param_endpoint, 0, sizeof(param_endpoint));
				}
			}

			line = _tcstok_s(nullptr, _T("\r\n"), &line_context);
		}

		SetFilePointer(
			config_file_handle,
			-static_cast<LONG>(last_newline_pos),
			nullptr,
			FILE_CURRENT
		);

		memset(buffer, '\0', sizeof(buffer));
	}
}

size_t size_of_folder(const LPCTSTR folder_path) {
	TCHAR wild_card[MAX_PATH] = {};

	_tcscpy_s(wild_card, folder_path);
	_tcscat_s(wild_card, _T("\\*"));

	WIN32_FIND_DATA file_info = {};
	const HANDLE enum_folder_handle = FindFirstFile(wild_card, &file_info);

	if (enum_folder_handle == INVALID_HANDLE_VALUE) {

		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] Failed to open cursor of path: %s\n"),
			GetLastError(),
			folder_path
		);

		append_text_to(logs_box, message_log);

		std::_Exit(EXIT_FAILURE);
	}

	size_t all_files_size = 0ull;

	do {
		if (file_info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			continue;

		all_files_size += (file_info.nFileSizeHigh * (MAXDWORD + 1)) + file_info.nFileSizeLow;

	} while (FindNextFile(enum_folder_handle, &file_info));

	FindClose(enum_folder_handle);

	return all_files_size;
}

TCHAR* get_and_place(const LPCTSTR url, const LPCTSTR file_path) {
	const HANDLE file_handle = CreateFile(
		file_path,
		FILE_APPEND_DATA,
		FILE_SHARE_READ,
		nullptr,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		nullptr
	);

	if (file_handle == INVALID_HANDLE_VALUE) {
		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] Failed to create file \'%s\'!\n"),
			GetLastError(),
			file_path
		);

		append_text_to(logs_box, message_log);

		std::_Exit(EXIT_FAILURE);
	}

	const HINTERNET internet_handle = InternetOpen(
		_T("CSSO_HW"),
		INTERNET_OPEN_TYPE_DIRECT,
		nullptr,
		nullptr,
		0
	);

	if (!internet_handle) {

		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] InternetOpen() failed!\n"),
			GetLastError()
		);

		append_text_to(logs_box,  message_log);

		CloseHandle(file_handle);
		std::_Exit(EXIT_FAILURE);
	}

	const HINTERNET connection_handle = InternetOpenUrl(
		internet_handle,
		url,
		agent_header,
		static_cast<DWORD>(_tcslen(agent_header)),
		INTERNET_FLAG_RELOAD,
		0
	);

	if (!connection_handle) {

		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] InternetOpenUrl() failed!\n"),
			GetLastError()
		);

		append_text_to(logs_box, message_log);

		InternetCloseHandle(internet_handle);
		CloseHandle(file_handle);
		std::_Exit(EXIT_FAILURE);
	}

	// log get request
	_sntprintf_s(
		message_log,
		message_log_size,
		_T("\r\nRequest: {\r\n\turl: %s,\r\n\tmethod: GET,\r\n\theaders: [\r\n\t\t%s\r\n\t]\r\n}\r\n"),
		url,
		agent_header
	);

	append_text_to(logs_box, message_log);

	DWORD bytes_read;
	CHAR buffer[page_size] = {};
	InternetReadFile(
		connection_handle,
		buffer,
		sizeof(buffer),
		&bytes_read
	);

	bytes_read++;

	strcat_s(buffer, "\n");

	// get status code
	TCHAR status_code[32] = {};
	DWORD status_code_len = 32;
	HttpQueryInfo(connection_handle, HTTP_QUERY_STATUS_CODE, status_code, &status_code_len, nullptr);

	if (!WriteFile(
		file_handle,
		buffer,
		bytes_read,
		nullptr,
		nullptr
	)) {

		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] Failed to write in \'%s\'\n"),
			GetLastError(),
			file_path
		);

		append_text_to(logs_box, message_log);

		CloseHandle(file_handle);
		InternetCloseHandle(connection_handle);
		InternetCloseHandle(internet_handle);
		std::_Exit(EXIT_FAILURE);
	}

	InternetCloseHandle(connection_handle);
	InternetCloseHandle(internet_handle);
	CloseHandle(file_handle);

#ifdef UNICODE
	TCHAR value[page_size] = {};
	MultiByteToWideChar(CP_UTF8, 0, buffer, -1, value, sizeof(value) >> 1);

	_sntprintf_s(
		message_log,
		message_log_size,
		_T("Response: {\r\n\tStatus: %s,\r\n\tdata: {\r\n\t\t%s\r\n\t}\r\n}\r\n"),
		status_code,
		value
	);

	append_text_to(logs_box, message_log);
	return _tcsdup(value);
#else
	_sntprintf_s(
		message_log,
		message_log_size,
		T("Response: {\r\n\tStatus: %s,\r\n\tdata: {\r\n\t\t%s\r\n\t}\r\n}\r\n"),
		status_code,
		buffer
	);

	append_text_to(logs_box, message_log);

	return strdup(buffer);
#endif
}

void post_data_to(const LPCTSTR url, const LPCTSTR data) {
	const HINTERNET internet_handle = InternetOpen(
		_T("CSSO_HW"),
		INTERNET_OPEN_TYPE_DIRECT,
		nullptr,
		nullptr,
		0
	);

	if (!internet_handle) {
		_tprintf(_T("[Error C%hu] InternetOpen() failed!\n"), GetLastError());

		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] InternetOpen() failed!\n"),
			GetLastError()
		);

		append_text_to(logs_box, message_log);

		std::_Exit(EXIT_FAILURE);
	}

	const HINTERNET connection_handle = InternetOpenUrl(
		internet_handle,
		url,
		agent_header,
		static_cast<DWORD>(_tcslen(agent_header)),
		INTERNET_FLAG_RELOAD,
		0
	);

	if (!connection_handle) {

		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] InternetOpenUrl() failed!\n"),
			GetLastError()
		);

		append_text_to(logs_box, message_log);

		InternetCloseHandle(internet_handle);
		std::_Exit(EXIT_FAILURE);
	}

	CHAR buffer[MAX_PATH] = {};
#ifdef UNICODE
	WideCharToMultiByte(CP_UTF8, 0, data, -1, buffer, sizeof(buffer), nullptr, nullptr);
#else
	buffer = data;
#endif

	// log request data
	_sntprintf_s(
		message_log,
		message_log_size,
		_T("\r\nRequest: {\r\n\turl: %s,\r\n\tmethod: POST,\r\n\theaders: [\r\n\t\t%s,\r\n\t\t%s\r\n\t],\r\n\tdata: {\r\n\t\t%s\r\n\t}\r\n}\r\n"),
		url,
		agent_header,
		post_content_type,
		data
	);

	append_text_to(logs_box, message_log);

	if (!HttpSendRequest(
		connection_handle,
		post_content_type,
		-1L,
		buffer,
		static_cast<DWORD>(strlen(buffer))
	)) {
		_sntprintf_s(
			message_log,
			message_log_size,
			_T("[Error C%hu] Failed to send request with the data: %s\n"),
			GetLastError(),
			data
		);

		append_text_to(logs_box, message_log);

		InternetCloseHandle(connection_handle);
		InternetCloseHandle(internet_handle);
		std::_Exit(EXIT_FAILURE);
	}

#ifdef UNICODE

#endif

	TCHAR status_code[32] = {};
	DWORD status_code_len = 32;
	HttpQueryInfo(connection_handle, HTTP_QUERY_STATUS_CODE, status_code, &status_code_len, nullptr);
	// log response
	_sntprintf_s(
		message_log,
		message_log_size,
		_T("Response: {\r\n\tstatus: %s\r\n}\r\n\r\n"),
		status_code
	);

	append_text_to(logs_box, message_log);

	InternetCloseHandle(connection_handle);
	InternetCloseHandle(internet_handle);
}

DWORD worker(LPVOID parameters){
	init();

	const auto api_url = static_cast<LPTSTR>(parameters);

	// extract student_identifier for url
	_tcscpy_s(student_identifier, _tcsrchr(api_url, _T('/')) + 1);

	// initialize user-agent header
	_sntprintf_s(
		agent_header,
		64,
		_T("User-Agent: %s"),
		student_identifier
	);

	get_contents_from(api_url);

	execute_config_instructions();

	const size_t file_sizes = size_of_folder(directories[download_folder_index]);

	post_stats(file_sizes, _T("https://cssohw.herokuapp.com/"));

	worker_thread_id = 0ul;

	append_text_to(logs_box, _T("Worker thread finished!\n"));

	return 0;
}

