#pragma once

#include <tchar.h>
#include <Windows.h>

constexpr DWORD page_size = 4096ul;
constexpr DWORD max_message = 160ul;

constexpr LPCTSTR directories[] = {
	_T("C:\\Facultate"),
	_T("C:\\Facultate\\CSSO"),
	_T("C:\\Facultate\\CSSO\\Week5"),
	_T("C:\\Facultate\\CSSO\\Week5\\Downloads")
};

constexpr DWORD download_folder_index = 3ul;

constexpr LPCTSTR config_file_path = _T("C:\\Facultate\\CSSO\\Week5\\myconfig.txt");

constexpr LPCTSTR post_content_type = _T("Content-Type: application/x-www-form-urlencoded");

DWORD get_requests_number, post_requests_number;

TCHAR agent_header[64];

TCHAR student_identifier[32];

constexpr DWORD message_log_size = INTERNET_MAX_URL_LENGTH;

TCHAR message_log[message_log_size];


